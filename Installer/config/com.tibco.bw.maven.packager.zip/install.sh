 #!/bin/bash
echo "Installing Maven Plugin to Maven Repository"
mvn install:install-file -Dfile=bw-archiver-1.0.0.jar -DpomFile=pom.xml
#EOF