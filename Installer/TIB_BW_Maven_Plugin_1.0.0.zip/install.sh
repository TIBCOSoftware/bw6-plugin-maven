 #!/bin/bash
echo "Starting Plugin Code for Apache Maven and TIBCO BusinessWorks™ installation .... " 
java -cp antpackage.jar org.apache.tools.ant.launch.Launcher 
#EOF