 #!/bin/bash
echo "Starting BW Maven Tool Installation ...." 
java -cp antpackage.jar org.apache.tools.ant.launch.Launcher 
#EOF